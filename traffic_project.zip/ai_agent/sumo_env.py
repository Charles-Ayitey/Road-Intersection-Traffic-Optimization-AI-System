import shutil
import os
import sys
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import traci

class SumoTrafficEnv(gym.Env):
    def __init__(self, sumocfg_path, use_gui=False, delta_time=5):
        super(SumoTrafficEnv, self).__init__()
        
        self.sumocfg_path = sumocfg_path
        self.use_gui = use_gui
        self.delta_time = delta_time
        
        # Determine SUMO binary
        binary_name = "sumo-gui" if use_gui else "sumo"
        self.sumo_binary = shutil.which(binary_name)
        
        if not self.sumo_binary:
            if 'SUMO_HOME' in os.environ:
                self.sumo_binary = os.path.join(os.environ['SUMO_HOME'], 'bin', binary_name)
                # On Windows, add .exe
                if os.name == 'nt' and not self.sumo_binary.endswith('.exe'):
                    self.sumo_binary += ".exe"
            else:
                # Default for Colab (Linux) or common Windows path
                if os.name == 'nt':
                    self.sumo_binary = r'C:\Program Files (x86)\Eclipse\Sumo\bin\sumo.exe'
                else:
                    self.sumo_binary = 'sumo'
            
        # Ensure tools are in sys.path
        if 'SUMO_HOME' in os.environ:
            tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
            if tools not in sys.path:
                sys.path.append(tools)
        elif os.path.exists('/usr/share/sumo/tools'): # Common Linux path
            sys.path.append('/usr/share/sumo/tools')
            
        # Define Action Space: 0: NS Green (Phase 0), 1: EW Green (Phase 2)
        self.action_space = spaces.Discrete(2)
        
        # Define Observation Space: 
        # [Queue_N, Queue_S, Queue_E, Queue_W, Current_Phase]
        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0, 0, 0], dtype=np.float32), 
            high=np.array([100, 100, 100, 100, 1], dtype=np.float32), 
            dtype=np.float32
        )

        self.tls_id = "center" 
        self.lanes = ["n2c_0", "s2c_0", "e2c_0", "w2c_0"]
        self.current_phase = 0 # 0 for NS, 1 for EW (mapped from SUMO 0/2)
        self.yellow_duration = 3

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        
        try:
            traci.close()
        except:
            pass
            
        sumo_cmd = [
            self.sumo_binary, 
            "-c", self.sumocfg_path, 
            "--no-warnings", 
            "--waiting-time-memory", "1000",
            "--seed", str(seed) if seed is not None else "42"
        ]
        
        traci.start(sumo_cmd)
        self.current_phase = 0
        traci.trafficlight.setPhase(self.tls_id, 0)
        
        return self._get_obs(), {}

    def _get_obs(self):
        queues = []
        for lane in self.lanes:
            queues.append(traci.lane.getLastStepHaltingNumber(lane))
        
        obs = np.array(queues + [float(self.current_phase)], dtype=np.float32)
        return obs

    def step(self, action):
        # Action 0 -> NS Green (SUMO Phase 0)
        # Action 1 -> EW Green (SUMO Phase 2)
        target_sumo_phase = 0 if action == 0 else 2
        
        # If we need to change the phase, we must use a yellow phase
        if target_sumo_phase != (0 if self.current_phase == 0 else 2):
            # Determine yellow phase: 
            # If current is NS G (0), yellow is NS Y (1)
            # If current is EW G (2), yellow is EW Y (3)
            yellow_phase = 1 if self.current_phase == 0 else 3
            
            # Switch to yellow
            traci.trafficlight.setPhase(self.tls_id, yellow_phase)
            for _ in range(self.yellow_duration):
                traci.simulationStep()
            
            # Now switch to target green
            traci.trafficlight.setPhase(self.tls_id, target_sumo_phase)
            self.current_phase = 0 if target_sumo_phase == 0 else 1
        
        # Run the simulation for delta_time (Green time)
        for _ in range(self.delta_time):
            traci.simulationStep()
            
        obs = self._get_obs()
        
        # Reward Calculation: minimize queues and waiting time
        total_queues = np.sum(obs[:4])
        total_waiting_time = sum([traci.lane.getWaitingTime(lane) for lane in self.lanes])
        
        reward = -float(total_queues + 0.1 * total_waiting_time)
        
        # Check if simulation finished or reached max time
        terminated = traci.simulation.getMinExpectedNumber() <= 0
        truncated = traci.simulation.getTime() > 3600 # 1 hour limit
        
        return obs, reward, terminated, truncated, {}

    def close(self):
        try:
            traci.close()
        except:
            pass

if __name__ == "__main__":
    # Test
    env = SumoTrafficEnv("simulation/junction.sumocfg")
    obs, _ = env.reset()
    print(f"Initial Obs: {obs}")
    for i in range(5):
        action = env.action_space.sample()
        obs, reward, term, trunc, _ = env.step(action)
        print(f"Step {i} | Action: {action}, Obs: {obs}, Reward: {reward}")
        if term or trunc: break
    env.close()
